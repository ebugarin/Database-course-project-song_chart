package artist.service;

public class artistException extends Exception {

	public artistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public artistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
