package album.service;

public class albumException extends Exception {

	public albumException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public albumException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
