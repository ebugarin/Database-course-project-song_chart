package songartist.service;

public class songartistException extends Exception {

	public songartistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public songartistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
