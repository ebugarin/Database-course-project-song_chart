package song.service;

public class songException extends Exception {

	public songException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public songException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
